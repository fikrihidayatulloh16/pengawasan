<?php
include 'db_connection.php';

$sql = "SELECT id_projek, nama_projek FROM m_projek";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<option value=\"{$row['id_projek']}\">{$row['id_projek']} - {$row['nama_projek']}</option>";
    }
} else {
    echo "<option disabled>Tidak ada projek tersedia</option>";
}
$conn->close();
?>
