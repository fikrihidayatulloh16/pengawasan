<?php
// Menghubungkan ke database
include 'db_connection.php';

// Pastikan ada parameter id_cuaca yang dikirimkan
if (isset($_GET['id'])) {
    $id_cuaca = $_GET['id'];

    // Query untuk menghapus data cuaca berdasarkan id_cuaca
    $query = "DELETE FROM cuaca WHERE id_cuaca = $id_cuaca";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Redirect kembali ke halaman cuaca.php setelah berhasil menghapus
        header("Location: ../cuaca.php");
        exit;
    } else {
        // Jika query gagal dijalankan
        die("Query error: " . mysqli_error($conn));
    }
} else {
    // Jika parameter id_cuaca tidak tersedia
    die("ID Cuaca tidak ditemukan.");
}
?>
