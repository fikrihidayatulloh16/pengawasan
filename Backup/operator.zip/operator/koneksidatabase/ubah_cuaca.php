<?php
include 'db_connection.php';

// Ambil id_cuaca dari parameter URL (harus diambil dari tombol "Ubah" di halaman data cuaca)
$id_cuaca = $_GET['id_cuaca'];

// Query untuk mengambil data cuaca berdasarkan id_cuaca
$query = "SELECT * FROM cuaca WHERE id_cuaca = '$id_cuaca'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query error: " . mysqli_error($conn));
}

$data = mysqli_fetch_assoc($result);

// Handle form submission untuk perubahan data cuaca
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_cuaca = $conn->real_escape_string($_POST['id_cuaca']);
    $jam_mulai = $conn->real_escape_string($_POST['jam_mulai']);
    $jam_selesai = $conn->real_escape_string($_POST['jam_selesai']);
    $kondisi = $conn->real_escape_string($_POST['kondisi']);

    // Query untuk update data cuaca
    $sql = "UPDATE cuaca SET jam_mulai = '$jam_mulai', jam_selesai = '$jam_selesai', kondisi = '$kondisi' WHERE id_cuaca = '$id_cuaca'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Data cuaca berhasil diubah!'); window.location.href = '../cuaca.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>
