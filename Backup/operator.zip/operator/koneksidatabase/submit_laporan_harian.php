<?php
include 'db_connection.php';

// Escape input and ensure all required fields are filled
$id_projek = $conn->real_escape_string($_POST['id_projek']);
$tanggal = $conn->real_escape_string($_POST['tanggal']);
$progress_harian = $conn->real_escape_string($_POST['progress_harian']);
$total_progres = $conn->real_escape_string($_POST['total_progres']);

if (empty($id_projek) || empty($tanggal) || empty($progress_harian) || empty($total_progres)) {
    echo "<script>alert('Error: Semua input harus diisi.'); window.location.href = '../laporanharian.php';</script>";
    exit;
}

// Generate unique ID for laporan harian
$result = $conn->query("SELECT COUNT(*) AS total FROM laporan_harian");
$row = $result->fetch_assoc();
$count = $row['total'] + 1;
$id_laporan_harian = 'L' . str_pad($count, 6, '0', STR_PAD_LEFT);

// Prepare and execute query to insert laporan harian
$sql = $conn->prepare("INSERT INTO laporan_harian (id_laporan_harian, id_projek, tanggal, progress_harian, total_progres) VALUES (?, ?, ?, ?, ?)");
$sql->bind_param('sssss', $id_laporan_harian, $id_projek, $tanggal, $progress_harian, $total_progres);

if ($sql->execute() === TRUE) {
    // Prepare and execute query to insert cuaca data
    $cuaca_data = [
        ['00:00', '01:00', 'cerah'],
        ['01:00', '02:00', 'cerah'],
        ['02:00', '03:00', 'cerah'],
        ['03:00', '04:00', 'cerah'],
        ['04:00', '05:00', 'cerah'],
        ['05:00', '06:00', 'cerah'],
        ['06:00', '07:00', 'cerah'],
        ['07:00', '08:00', 'cerah'],
        ['08:00', '09:00', 'cerah'],
        ['09:00', '10:00', 'cerah'],
        ['10:00', '11:00', 'cerah'],
        ['11:00', '12:00', 'cerah'],
        ['12:00', '13:00', 'cerah'],
        ['13:00', '14:00', 'cerah'],
        ['14:00', '15:00', 'cerah'],
        ['15:00', '16:00', 'cerah'],
        ['16:00', '17:00', 'cerah'],
        ['17:00', '18:00', 'cerah'],
        ['18:00', '19:00', 'cerah'],
        ['19:00', '20:00', 'cerah'],
        ['20:00', '21:00', 'cerah'],
        ['21:00', '22:00', 'cerah'],
        ['22:00', '23:00', 'cerah'],
        ['23:00', '24:00', 'cerah']
    ];

    $sql_cuaca = $conn->prepare("INSERT INTO cuaca (id_laporan_harian, jam_mulai, jam_selesai, kondisi) VALUES (?, ?, ?, ?)");
    foreach ($cuaca_data as $data) {
        list($jam_mulai, $jam_selesai, $kondisi) = $data;
        $sql_cuaca->bind_param('ssss', $id_laporan_harian, $jam_mulai, $jam_selesai, $kondisi);
        $sql_cuaca->execute();
    }

    echo "<script>alert('Data berhasil disimpan!'); window.location.href = '../laporanharian.php';</script>";
} else {
    echo "<script>alert('Error: " . $sql->error . "'); window.location.href = '../laporanharian.php';</script>";
}

$conn->close();
?>
